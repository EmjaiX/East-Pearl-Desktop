window.require = require;
// window.addEventListener('DOMContentLoaded', () => {})